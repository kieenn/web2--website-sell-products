<?php 
require_once('connect.php');
$name = $_REQUEST['name'];
$phoneNum = $_REQUEST['phoneNum'];
$address = $_REQUEST['address'];
$status = $_REQUEST['status'];
$id = $_REQUEST['id'];
echo $id;
$conn = open_db();
$sql = "UPDATE `web`.`xulydonhang` SET `name`='$name' WHERE  `id`=$id;";
if ($conn->query($sql) === TRUE) {
    echo "The record editted successfully";
    header("Location:" . 'products.php');
    exit();
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
echo $sql;


close_db();

?>
