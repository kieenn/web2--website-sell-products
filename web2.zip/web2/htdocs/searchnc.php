<!DOCTYPE html>
<html lang="vi" class="h-100">
<?php
require_once('lib_session.php');
require_once ('pagination.php');
require_once ('connect.php');

?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nền tảng - Kiến thức cơ bản về WEB | Bảng tin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Custom css - Các file css do chúng ta tự viết -->
    <link rel="stylesheet" href="../assets/css/app.css" type="text/css">
	
    <body>
<?php
$conn = open_db();
$tim_kiem = $_REQUEST['keyword_tensanpham'];
 $type = $_REQUEST['type'];
 $min = $_REQUEST['min'];
 $max = $_REQUEST['max'];
 if($type == ''){
    $mysql_query = mysqli_query($conn, "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%'");
     $total_rows = mysqli_num_rows($mysql_query);
     $limit = 8;
     $total_page = ceil($total_rows/$limit);
     $current_page=0;
     $offset=0;
     $request_url = basename($_SERVER['REQUEST_URI']);
     $pagination = create_pagination($request_url, $limit, $total_page, $current_page);
 
     if( isset($_GET{'page'} ) ) {
         $current_page = $_GET['page'];
         if($current_page <=0)
             $current_page = 1;
         else if($current_page > $total_page)
             $current_page = $total_page;
         $offset = $limit * ($current_page-1);
     }
     else{
         $current_page = 1;
         $offset = 0;
     }
     $sql = "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' Limit $offset, $limit;";
 }else{
 if($min == '' && $max ==''){
     $mysql_query = mysqli_query($conn, "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' AND Loai LIKE '%$type%'");
     $total_rows = mysqli_num_rows($mysql_query);
     $limit = 8;
     $total_page = ceil($total_rows/$limit);
     $current_page=0;
     $offset=0;
     $request_url = basename($_SERVER['REQUEST_URI']);
     $pagination = create_pagination($request_url, $limit, $total_page, $current_page);
 
     if( isset($_GET{'page'} ) ) {
         $current_page = $_GET['page'];
         if($current_page <=0)
             $current_page = 1;
         else if($current_page > $total_page)
             $current_page = $total_page;
         $offset = $limit * ($current_page-1);
     }
     else{
         $current_page = 1;
         $offset = 0;
     }
     $sql = "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' AND Loai LIKE '%$type%' Limit $offset, $limit;";
 }else if($min == ''){
     $mysql_query = mysqli_query($conn, "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' AND Loai LIKE '%$type%' AND GiaSP <= $max");
     $total_rows = mysqli_num_rows($mysql_query);
     $limit = 8;
     $total_page = ceil($total_rows/$limit);
     $current_page=0;
     $offset=0;
     $request_url = basename($_SERVER['REQUEST_URI']);
     $pagination = create_pagination($request_url, $limit, $total_page, $current_page);
 
     if( isset($_GET{'page'} ) ) {
         $current_page = $_GET['page'];
         if($current_page <=0)
             $current_page = 1;
         else if($current_page > $total_page)
             $current_page = $total_page;
         $offset = $limit * ($current_page-1);
     }
     else{
         $current_page = 1;
         $offset = 0;
     }
     $sql = "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' AND Loai LIKE '%$type%' AND GiaSP <= $max Limit $offset, $limit;";
 }else{
     $mysql_query = mysqli_query($conn, "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' AND Loai LIKE '%$type%' AND  GiaSP >= $min AND GiaSP <= $max ");
     $total_rows = mysqli_num_rows($mysql_query);
     $limit = 8;
     $total_page = ceil($total_rows/$limit);
     $current_page=0;
     $offset=0;
     $request_url = basename($_SERVER['REQUEST_URI']);
     $pagination = create_pagination($request_url, $limit, $total_page, $current_page);
 
     if( isset($_GET{'page'} ) ) {
         $current_page = $_GET['page'];
         if($current_page <=0)
             $current_page = 1;
         else if($current_page > $total_page)
             $current_page = $total_page;
         $offset = $limit * ($current_page-1);
     }
     else{
         $current_page = 1;
         $offset = 0;
     }
     $sql = "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' AND Loai LIKE '%$type%' AND  GiaSP >= $min AND GiaSP <= $max Limit $offset, $limit;";
 }
}

 // $sql = "SELECT * FROM sanpham WHERE TenSP LIKE '%$tim_kiem%' Limit $offset, $limit;";
 $result = mysqli_query($conn, $sql);
 $countDBRows = mysqli_num_rows($result);

?>
    <!-- header -->
    <style>
    .dropbtn {
    background-color: #4CAF50;
    color: #343a40;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }
  
  .dropdown {
    position: relative;
    display: inline-block;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #343a40;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown:hover .dropbtn {
    background-color: #3e8e41;
  }
</style>
    <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-dark">
        <div class="container">
            <a class="navbar-brand" href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a>
            <div class="navbar-collapse collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Trang chủ <span class="sr-only">(current)</span></a>
                    </li>
                  
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="products.php" class="nav-link">San Pham</a> 
                            <div class="dropdown-content">
                                <a href="dt.php">Dien Thoai</a>
                                <a href="lt.php">LapTop</a>
                                <a href="tb.php">Tablet</a>
                            </div>
                        </div>
                    </li>
                    <?php
							if (isAdminLogged()) {?>
                    
                        <li class="nav-item">
                        <a class="nav-link" href="new_product.php">Thêm Sản phẩm</a> 
                        <?php
                    }?>
						
                    
                    </li>
                    <li class="nav-item">
                    <?php
							if (isAdminLogged()) {?>
                        <a class="nav-link" href="quanlydonhang.php">Quan ly don hang</a> 
                        <?php
                    }?>
                    </li>
                </ul>
                <form class="form-inline mt-2 mt-md-0" method="get" action="search.php">
                    <input class="form-control mr-sm-2" type="text" placeholder="Tìm kiếm" aria-label="Search"
                        name="keyword_tensanpham">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Tìm kiếm</button>
                </form>
            </div>
            <ul class="navbar-nav px-3">
                <li class="nav-item text-nowrap">
                    <a class="nav-link" href="cart.php">Giỏ hàng</a>
                </li>
                <li class="nav-item text-nowrap">
                    <!-- Nếu chưa đăng nhập thì hiển thị nút Đăng nhập -->
                    <?php
						//var_dump(isAdminLogged());
						if(isAdminLogged()) {
							echo ('<span style="color:red">Admin is logging</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
						}else if(isLogged()){
                            $name = $_SESSION['current_username'];
                            $query ="SELECT customer.name, customer.id FROM customer WHERE customer.username = '$name';";
                            $res = mysqli_query($conn, $query);
                            $r = mysqli_fetch_assoc($res);
                            echo('<input name ="idCus" type="hidden" value ="'.$r['id'].'">');
                            echo ('<span style="color:red">'.$r['name'].'</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
                        }
						else {
							echo ('<a class ="nav-link" href="login.php">Đăng nhập</a>');
						}
					?>
                    
                </li>
            </ul>
        </div>
    </nav>
    <!-- end header -->

    <main role="main">
        <!-- Block content - Đục lỗ trên giao diện bố cục chung, đặt tên là `content` -->
        <!-- Danh sách sản phẩm -->
        <section class="jumbotron text-center">
            <div class="container">
                <h1 class="jumbotron-heading">Ket Qua Tim Kiem '<?=$tim_kiem?>'</h1>
                <p class="lead text-muted">Các sản phẩm với chất lượng, uy tín, cam kết từ nhà Sản xuất, phân phối và
                    bảo hành
                    chính hãng.</p>
					<h6>Trang <?=$current_page?></h1>
            </div>
        </section>

        <!-- Giải thuật duyệt và render Danh sách sản phẩm theo dòng, cột của Bootstrap -->
        <div class="danhsachsanpham py-5 bg-light">
            <div class="container">
            <form name="frmTimKiem" method="get" action="searchnc.php">
                <h1 class="text-center">Tìm kiếm sản phẩm</h1>
                <div class="row">
                    <div class="col col-md-12">
                        <h5 class="text-center">Cung cấp kiến thức nền tảng về Lập trình, Thiết kế Web, Cơ sở dữ liệu
                        </h5>
                        <h5 class="text-center">Giúp các bạn có niềm tin, hành trang kiến thức vững vàng trên con đường
                            trở
                            thành Nhà phát triển Phần mềm</h5>
                        <div class="text-center">
                            <button type="reset" id="btnReset" class="btn btn-warning">Xóa bộ lọc</button>
                            <button type ="submit" class="btn btn-primary btn-lg" name="search2">Tìm kiếm <i class="fa fa-forward"
                                    aria-hidden="true"></i></button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <aside class="col-sm-4">
                        <p>Bộ lọc </p>
                        <div class="card">
                            <!-- Tìm kiếm theo tên sản phẩm -->
                            <article class="card-group-item">
                                <header class="card-header">
                                    <h6 class="title">Tên sản phẩm </h6>
                                </header>
                                <div class="filter-content">
                                    <div class="card-body">
                                        <input class="form-control" type="text" placeholder="Tìm kiếm"
                                            aria-label="Search" name="keyword_tensanpham" value="">
                                    </div> <!-- card-body.// -->
                                </div>
                            </article> <!-- // Tìm kiếm theo Tên sản phẩm -->

                            <!-- Tìm kiếm theo Loại sản phẩm -->
                            <article class="card-group-item">
                                <header class="card-header">
                                    <h6 class="title">Loại sản phẩm </h6>
                                </header>
                                <div class="filter-content">
                                    <div class="card-body">
                                    <input type="hidden" name="type" value="">
                                    <label data-text="JavaScript">
                                        <input type="radio" name="type" value="1"> Dien Thoai
                                        <span class="dot"></span>
                                        <span class="dot-shadow"></span>
                                    </label>
                                    <label data-text="PHP">
                                        <input type="radio" name="type" value="2"> Laptop
                                        <span class="dot"></span>
                                        <span class="dot-shadow"></span>
                                    </label>
                                    <label data-text="Python">
                                        <input type="radio" name="type" value="3"> Tablet
                                        <span class="dot"></span>
                                        <span class="dot-shadow"></span>
                                    </label>
                                    </div> <!-- card-body.// -->
                                </div>
                            </article> <!-- // Tìm kiếm theo Loại sản phẩm -->

                            <!-- Tìm kiếm theo Nhà sản xuất -->
                            

                            <!-- Tìm kiếm theo Khuyến mãi -->
                            <article class="card-group-item">
                                <header class="card-header">
                                    <h6 class="title">Khuyến mãi </h6>
                                </header>
                                <div class="filter-content">
                                    <div class="card-body">
                                    </div> <!-- card-body.// -->
                                </div>
                            </article> <!-- // Tìm kiếm theo Nhà sản xuất -->

                            <!-- Tìm kiếm theo khoảng giá tiền -->
                            <article class="card-group-item">
                                <header class="card-header">
                                    <h6 class="title">Khoảng tiền </h6>
                                </header>
                                <div class="filter-content">
                                    <div class="card-body">
                                        <div class="form-row">
                                            <input type="number" name='min' class="form-control"> <label for="">to</label> <input type="number" name='max' class="form-control">
                                        </div>
                                    </div> <!-- card-body.// -->
                                </div>
                            </article> <!-- // Tìm kiếm theo khoảng giá tiền -->

                            <!-- Tìm kiếm theo màu sắc sản phẩm -->
                        </div> <!-- card.// -->
                    </aside> <!-- col.// -->

                    <!-- Giải thuật duyệt và render Danh sách sản phẩm theo dòng, cột của Bootstrap -->
                    <div class="col-sm-8 mt-2">
			<?php
				//var_dump($countDBRows);
				$countUIRow = 0;
				$s = '';
				while($row = mysqli_fetch_assoc($result)) {
					if($countUIRow == 0) {
						echo '<div class="row">';
					}
					// add col
					echo '<div class="col-md-6">';
					
					// content of col here ?>
                    
					<div class="card mb-4 shadow-sm">
						<a href="product-detail.php?idSp=<?=$row['id']?>">
							<img class="bd-placeholder-img card-img-top" width="100%" height="350"
								src="<?=$row['HinhSP']?>">
						</a>
						<div class="card-body">
							<a href="product-detail.php">
								<h5><?=$row['TenSP']?></h5>
							</a>
							<h6>Điện thoại</h6>                         
							<div class="d-flex justify-content-between align-items-center">
								<div class="btn-group">
									
								</div>
								<small class="text-muted text-right">
									<b><?=number_format($row['GiaSP'], 0, '', ',')?> vnđ</b>
								</small>
							</div>
							<?php
							if (isAdminLogged()) { ?>
							<div class="d-flex justify-content-between align-items-center">
								<a href="edit_product.php?id=<?=$row['id']?>">Edit</a>
                                <a href="qlsp.php?del=1&id=<?=$row['id']?>" onclick="return confirm('Are you sure?');">Del</a>
							</div>
							<?php
							}
							?>
						</div>
					</div>
					<?php
					echo '</div>'; // end of col
					$countUIRow++;
					if($countUIRow == 2) {
						echo '</div>'; // end of row
						$countUIRow = 0;
					}
				};
				if($countUIRow > 0) {
					echo '</div>';
				}
				//echo $s;
			?>
            </div>
            </form>
        </div>
        <!-- End block content -->
    </main>
    <div class="navigation" style=" text-align: center;"><?php echo $pagination; ?></div>
	
	<?php close_db();?>
    <!-- footer -->
    <footer class="footer mt-auto py-3">
        <div class="container">
            <span>Bản quyền © bởi <a href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a> - <script>document.write(new Date().getFullYear());</script>.</span>
            <span class="text-muted">Hành trang tới Tương lai</span>

            <p class="float-right">
                <a href="#">Về đầu trang</a>
            </p>
        </div>
    </footer>
    <!-- end footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/popperjs/popper.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom script - Các file js do mình tự viết -->
    <script src="../assets/js/app.js"></script>

</body>

</html>