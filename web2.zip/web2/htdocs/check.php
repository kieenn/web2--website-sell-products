
<?php 
// PHP program to get the 
// current date and time 
  
echo "Current date and time is :"; 
  
// Store the date and time  to 
// the variable 
$myDate = date("Y-d-m");
  
// Display the date and time 
$prev_date = date('d-m-Y', strtotime(' +30 day'));
echo $prev_date;
  
?> 