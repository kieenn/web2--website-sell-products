<?php
require_once('connect.php');
$conn=open_db();
if(isset($_REQUEST['btnSuaSP'])) {
    $ten = $_REQUEST['sp_ten'];
    //$hinh = $_REQUEST['sp_hinh'];
    $gia = $_REQUEST['sp_gia'];
    $loai = $_REQUEST['sp_loai'];
    $id = $_REQUEST['id'];


    // Create connection


    if($_FILES['fileToUpload']['name']=='') {
        //No file selected
        $sql = sprintf("UPDATE `sanpham` SET `TenSP` = '%s', `GiaSP` = '%lf', `Loai` = '%d' WHERE `id` = %d;", $ten, $gia, $loai, $id);
    }
    else {
        $hinh = '';
        uploadHinh($hinh);
        $sql = sprintf("UPDATE `sanpham` SET `TenSP` = '%s', `GiaSP` = '%lf', `Loai` = '%d', `HinhSP` = '%s' WHERE `id` = %d;", $ten, $gia, $loai, $hinh, $id);
    }
    if ($conn->query($sql) === TRUE) {
        echo "The record editted successfully";
        header("Location:" . 'products.php');
        exit();
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}

if(isset($_REQUEST['del'])) {
    $id = $_REQUEST['id'];



    // Check connection


    $sql = sprintf("DELETE FROM sanpham, cartitem WHERE cartitem.id_product = sanpham.id AND sanpham.id= %d",$id);

    if ($conn->query($sql) === TRUE) {
        echo "The record deleted successfully";
        header("Location:" . 'products.php');
        exit();
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
if(isset($_REQUEST['del1'])) {
    $id = $_REQUEST['id'];
    $id_cart = $_REQUEST['idCart'];


    // Check connection


    $sql = sprintf("DELETE FROM cartitem WHERE id = $id AND idCart = $id_cart");

    if ($conn->query($sql) === TRUE) {
        echo "The record deleted successfully";
        header("Location:" . 'cart.php');
        exit();
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
if(isset($_REQUEST['del2'])) {
    $id = $_REQUEST['id'];



    // Check connection


    $sql = sprintf("DELETE FROM qldh WHERE `id` = %d", $id);

    if ($conn->query($sql) === TRUE) {
        echo "The record deleted successfully";
        header("Location:" . 'quanlydonhang.php');
        exit();
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}

if(isset($_REQUEST['btnThemSP'])) {
    $ten = $_REQUEST['sp_ten'];
    //$hinh = $_REQUEST['sp_hinh'];
    $hinh = '';
    uploadHinh($hinh);
    $gia = $_REQUEST['sp_gia'];
    $loai = $_REQUEST['sp_loai'];
    $mota = $_REQUEST['sp_mota'];

    // Create connection
    // Check connection


    $sql = sprintf("INSERT INTO `sanpham` (`id`, `TenSP`, `HinhSP`, `GiaSP`, `Loai`, `Mota`) VALUES (NULL, '%s', '%s', '%lf','%d' ,'%s')", $ten, $hinh, $gia, $loai, $mota);

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        header("Location:" . 'products.php');
        exit();
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}



function uploadHinh(&$hinh) {
    $target_dir = "imgs/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    // echo $target_file;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
    }

    // Check if file already exists
    if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $hinh = $target_file;
    //$uploadOk = 0;
    return 1;
    }

    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
        $hinh = $target_file;
        echo $hinh;
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
    }

    return $uploadOk;
}
?>