<?php
session_start();

function isAdminLogged() {
	//var_dump($_SESSION['current_username']);
	if(isset($_SESSION['current_username'])) {
		//var_dump($_SESSION['isAdmin']);
		if ($_SESSION['isAdmin'] == true)
			return true;
	}
	
	return false; 
}

function isLogged(){
	if(isset($_SESSION['current_username'])) {
		return true;
	}
	return false;
}
?>