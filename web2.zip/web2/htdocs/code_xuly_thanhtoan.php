<?php 
require_once('connect.php');
$conn = open_db();
$name = $_REQUEST['kh_ten'];
$phoneNum = $_REQUEST['kh_dienthoai'];
$address = $_REQUEST['kh_diachi'];
$type = $_REQUEST['httt_ma'];
// $charset = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
// $id_order = '';
// $desired_length = 10;
// while(strlen($id_order) < $desired_length){
//   $id_order .= substr(str_shuffle($charset), 0, 1);
// }
// $idOrder = $id_order;
$id_cart = $_REQUEST['idCart'];
$id_cus = $_REQUEST['idCus'];
$sum = $_REQUEST['sum'];
$myDate = date("Y-d-m");
$sql = sprintf("UPDATE `cart` SET `status` = 1 WHERE id_cus = $id_cus AND STATUS =0");
if ($conn->query($sql) === TRUE) {
    $sql = sprintf("UPDATE `customer` SET name ='$name', phoneNum = '$phoneNum', address ='$address' WHERE id = $id_cus;");
    if ($conn->query($sql) === TRUE) {
        $sql = sprintf("INSERT INTO hoadon (id_cus, id_cart, hoadon.Time, typePayment, sum,expected_deli ) VALUES ('$id_cus','$id_cart', CURDATE(), '$type','$sum',DATE_ADD(CURDATE(), INTERVAL 7 DAY))");
        if ($conn->query($sql) === TRUE) {
            $idHD = $conn->insert_id;
            $sql = sprintf("INSERT INTO qldh (idHD) VALUES ('$idHD')");
            if ($conn->query($sql) === TRUE) {
                        $sql = sprintf("INSERT INTO cart (id_cus) VALUES ('$id_cus')");
                        if ($conn->query($sql) === TRUE) {
                            echo "New record created successfully";
                            header("Location:" . 'products.php');
                            exit();
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
            
                        $conn->close();
                    }
            } 
    }
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();




?>


