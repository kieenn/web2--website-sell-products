<!DOCTYPE html>
<html lang="vi" class="h-100">
<?php
require_once('lib_session.php');
require_once('connect.php');
?>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nền tảng - Kiến thức cơ bản về WEB | Bảng tin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Custom css - Các file css do chúng ta tự viết -->
    <link rel="stylesheet" href="../assets/css/product-detail.css" type="text/css">
</head>

<body>
<?php
$conn = open_db();
$sql = "SELECT * FROM sanpham WHERE id = ".$_REQUEST['idSp'];
$result = mysqli_query($conn, $sql);
$countDBRows = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);

?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nền tảng - Kiến thức cơ bản về WEB | Bảng tin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Custom css - Các file css do chúng ta tự viết -->
    <link rel="stylesheet" href="assets/css/app.css" type="text/css">
    <link rel="stylesheet" href="dropdown.css">
</head>
<body>
     <!-- header -->
     <style>
    .dropbtn {
    background-color: #4CAF50;
    color: #343a40;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }
  
  .dropdown {
    position: relative;
    display: inline-block;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #343a40;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown:hover .dropbtn {
    background-color: #3e8e41;
  }
</style>
    <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-dark">
        <div class="container">
            <a class="navbar-brand" href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a>
            <div class="navbar-collapse collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Trang chủ <span class="sr-only">(current)</span></a>
                    </li>
                  
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="products.php" class="nav-link">San Pham</a> 
                            <div class="dropdown-content">
                                <a href="dt.php">Dien Thoai</a>
                                <a href="lt.php">LapTop</a>
                                <a href="tb.php">Tablet</a>
                            </div>
                        </div>
                    </li>
                    <?php
							if (isAdminLogged()) {?>
                    
                        <li class="nav-item">
                        <a class="nav-link" href="new_product.php">Thêm Sản phẩm</a> 
                        <?php
                    }?>
						
                    
                    </li>
                    <li class="nav-item">
                    <?php
							if (isAdminLogged()) {?>
                        <a class="nav-link" href="quanlydonhang.php">Quan ly don hang</a> 
                        <?php
                    }?>
                    </li>
                </ul>
                <form class="form-inline mt-2 mt-md-0" method="get" action="search.php">
                    <input class="form-control mr-sm-2" type="text" placeholder="Tìm kiếm" aria-label="Search"
                        name="keyword_tensanpham">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Tìm kiếm</button>
                </form>
            </div>
            <ul class="navbar-nav px-3">
                <li class="nav-item text-nowrap">
                    <a class="nav-link" href="cart.php">Giỏ hàng</a>
                </li>
                <li class="nav-item text-nowrap">
                    <!-- Nếu chưa đăng nhập thì hiển thị nút Đăng nhập -->
                    <?php
						//var_dump(isAdminLogged());
						if(isAdminLogged()) {
							echo ('<span style="color:red">Admin is logging</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
						}else if(isLogged()){
                            $name = $_SESSION['current_username'];
                            $query ="SELECT customer.name, customer.id FROM customer WHERE customer.username = '$name';";
                            $res = mysqli_query($conn, $query);
                            $r = mysqli_fetch_assoc($res);
                            echo('<input name ="idCus" type="hidden" value ="'.$r['id'].'">');
                            echo ('<span style="color:red">'.$r['name'].'</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
                        }
						else {
							echo ('<a class ="nav-link" href="login.php">Đăng nhập</a>');
						}
					?>
                    
                </li>
            </ul>
        </div>
    </nav>
    <!-- end header -->

    <main role="main">
        <!-- Block content - Đục lỗ trên giao diện bố cục chung, đặt tên là `content` -->
        <div class="container mt-4">
            <div id="thongbao" class="alert alert-danger d-none face" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <?php
                if(isset($_GET['btnThemVaoGioHang'])){
                    if(islogged()){
                        $idSP = $_REQUEST['idSP'];
                        $id_cus = $r['id']; 
                        $quantity = $_GET['soluong'];
                        $query = "SELECT id FROM cart WHERE id_cus = $id_cus AND STATUS =0";
                        $check = mysqli_query($conn, $query);
                        $countDBRows = mysqli_num_rows($check);
                        if($countDBRows > 0){ 
                            $checkid = mysqli_fetch_assoc($check);
                            $id_cart = $checkid['id'];
                        $sql = sprintf("INSERT INTO cartitem (idCart, id_product,quantity) VALUES ('$id_cart','$idSP','$quantity')");
                        $conn->query($sql);
                        }else{
                            $sql1 = sprintf("INSERT INTO cart (id_cus) VALUES ('$id_cus')");
                            $conn->query($sql1);
                            $id_cart = $conn->insert_id;
                            $sql = sprintf("INSERT INTO cartitem (idCart, id_product,quantity) VALUES ('$id_cart','$idSP','$quantity')");
                            $conn->query($sql);
                        }
                        }
                        
                }
            ?>

            <div class="card">
                <div class="container-fliud">
                    <form name="frmsanphamchitiet" id="frmsanphamchitiet" method="get"
                        action="product-detail.php">
                        <!-- <input type="hidden" name="sp_ma" id="sp_ma" value="5">
                        <input type="hidden" name="sp_ten" id="sp_ten" value="Samsung Galaxy Tab 10.1 3G 16G">
                        <input type="hidden" name="sp_gia" id="sp_gia" value="10990000.00">
                        <input type="hidden" name="hinhdaidien" id="hinhdaidien" value="samsung-galaxy-tab-10.jpg"> -->

                        <div class="wrapper row">
                            <div class="preview col-md-6">
                                <div class="preview-pic tab-content">
                                    <div class="tab-pane" id="pic-1">
                                        <img src="<?=$row['HinhSP']?>">
                                    </div>
                                    <div class="tab-pane" id="pic-2">
                                    <img src="<?=$row['HinhSP']?>">
                                    </div>
                                    <div class="tab-pane active" id="pic-3">
                                    <img src="<?=$row['HinhSP']?>">
                                    </div>
                                </div>
                                <ul class="preview-thumbnail nav nav-tabs">
                                    <li class="active">
                                        <a data-target="#pic-1" data-toggle="tab" class="">
                                        <img style="width:100%;" src="<?=$row['HinhSP']?>">
                                        </a>
                                    </li>
                                    <li class="">
                                        <a data-target="#pic-2" data-toggle="tab" class="">
                                        <img  style="width:100%;" src="<?=$row['HinhSP']?>">
                                        </a>
                                    </li>
                                    <li class="">
                                        <a data-target="#pic-3" data-toggle="tab" class="active">
                                        <img  style="width:100%;" src="<?=$row['HinhSP']?>">
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="details col-md-6">
                                <h3 class="product-title"><?= $row['TenSP']?></h3>
                                <div class="rating">
                                    <div class="stars">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    </div>
                                    <span class="review-no">999 reviews</span>
                                </div>
                                <!-- <p class="product-description">Màn hình 10.1 inch cảm ứng đa điểm</p> -->
                                <!-- <small class="text-muted">Giá cũ: <s><span>10,990,000.00 vnđ</span></s></small> -->
                                <h4 class="price">Giá hiện tại: <span><?=number_format($row['GiaSP'], 0, '', ',')?></span></h4>
                                <p class="vote"><strong>100%</strong> hàng <strong>Chất lượng</strong>, đảm bảo
                                    <strong>Uy
                                        tín</strong>!</p>
                            
                                <div class="form-group">
                                    <label for="soluong">Số lượng đặt mua:</label>
                                    
                                    <input type="number" name ="soluong" value ="1" >
                                </div>
                                <div class="action">
                                <input type="hidden" name ="idSP" value ="<?=$row['id'] ?>">
                                <input type="hidden" name ="idSp" value ="<?=$_REQUEST['idSp'] ?>">
                                    <button class="add-to-cart btn btn-default" id="btnThemVaoGioHang" name="btnThemVaoGioHang" add=1><i class="fa fa-shopping-cart" type ="submit"></i></i></button>
                                    <a class="like btn btn-default" href=""><span class="fa fa-heart"></span></a>
                                </div>
                                <?php
							if (isAdminLogged()) { ?>
							<div class="d-flex justify-content-between align-items-center">
								<a href="edit_product.php?id=<?=$row['id']?>">Edit</a>
                                <a href="qlsp.php?del=1&id=<?=$row['id']?>" onclick="return confirm('Are you sure?');">Del</a>
							</div>
							<?php
							}
							?>
                            </div>
                        
                        </div>
                        
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="container-fluid">
                    <h3>Thông tin chi tiết về Sản phẩm</h3>
                    <div class="row">
                        <div class="col">
                            Vi xử lý Dual-core 1 Cortex-A9 tốc độ 1GHz
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End block content -->
    </main>
<?php close_db();?>
    <!-- footer -->
    <footer class="footer mt-auto py-3">
        <div class="container">
            <span>Bản quyền © bởi <a href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a> - <script>document.write(new Date().getFullYear());</script>.</span>
            <span class="text-muted">Hành trang tới Tương lai</span>

            <p class="float-right">
                <a href="#">Về đầu trang</a>
            </p>
        </div>
    </footer>
    <!-- end footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/popperjs/popper.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom script - Các file js do mình tự viết -->
    <script src="../assets/js/app.js"></script>

</body>

</html>