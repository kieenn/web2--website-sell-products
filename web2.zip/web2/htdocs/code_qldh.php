<?php
require_once('connect.php');
$conn = open_db();
$status = $_REQUEST['status'];
$id = $_REQUEST['idDH'];
$sql = sprintf("UPDATE qldh SET STATUS = '%d' WHERE id = %d", $status, $id);
$result = mysqli_query($conn, $sql);
$conn->query($sql);
header("Location:" . 'quanlydonhang.php');
?>