<!DOCTYPE html>
<html lang="vi" class="h-100">
<?php 
require_once('lib_session.php');
require_once('connect.php');
$conn = open_db();
   
?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nền tảng - Kiến thức cơ bản về WEB | Bảng tin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Custom css - Các file css do chúng ta tự viết -->
    <link rel="stylesheet" href="../assets/css/app.css" type="text/css">
</head>

<body>
     <!-- header -->
     <style>
    .dropbtn {
    background-color: #4CAF50;
    color: #343a40;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }
  
  .dropdown {
    position: relative;
    display: inline-block;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #343a40;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown:hover .dropbtn {
    background-color: #3e8e41;
  }
</style>
    <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-dark">
        <div class="container">
            <a class="navbar-brand" href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a>
            <div class="navbar-collapse collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Trang chủ <span class="sr-only">(current)</span></a>
                    </li>
                  
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="products.php" class="nav-link">San Pham</a> 
                            <div class="dropdown-content">
                                <a href="dt.php">Dien Thoai</a>
                                <a href="lt.php">LapTop</a>
                                <a href="tb.php">Tablet</a>
                            </div>
                        </div>
                    </li>
                    <?php
							if (isAdminLogged()) {?>
                    
                        <li class="nav-item">
                        <a class="nav-link" href="new_product.php">Thêm Sản phẩm</a> 
                        <?php
                    }?>
						
                    
                    </li>
                    <li class="nav-item">
                    <?php
							if (isAdminLogged()) {?>
                        <a class="nav-link" href="quanlydonhang.php">Quan ly don hang</a> 
                        <?php
                    }?>
                    </li>
                </ul>
                <form class="form-inline mt-2 mt-md-0" method="get" action="search.php">
                    <input class="form-control mr-sm-2" type="text" placeholder="Tìm kiếm" aria-label="Search"
                        name="keyword_tensanpham">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Tìm kiếm</button>
                </form>
            </div>
            <ul class="navbar-nav px-3">
                <li class="nav-item text-nowrap">
                    <a class="nav-link" href="cart.php">Giỏ hàng</a>
                </li>
                <li class="nav-item text-nowrap">
                    <!-- Nếu chưa đăng nhập thì hiển thị nút Đăng nhập -->
                    <?php
						//var_dump(isAdminLogged());
						if(isAdminLogged()) {
							echo ('<span style="color:red">Admin is logging</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
						}else if(isLogged()){
                            $name = $_SESSION['current_username'];
                            $query ="SELECT customer.name, customer.id FROM customer WHERE customer.username = '$name';";
                            $res = mysqli_query($conn, $query);
                            $r = mysqli_fetch_assoc($res);
                            echo('<input name ="idCus" type="hidden" value ="'.$r['id'].'">');
                            echo ('<span style="color:red">'.$r['name'].'</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
                        }
						else {
							echo ('<a class ="nav-link" href="login.php">Đăng nhập</a>');
						}
					?>
                    
                </li>
            </ul>
        </div>
    </nav>
    <!-- end header -->

    <main role="main">
    <form name="themSP" method="get" action="code_qldh.php" enctype="multipart/form-data">
        <!-- Block content - Đục lỗ trên giao diện bố cục chung, đặt tên là `content` -->
        <div class="container mt-4">
            <div id="thongbao" class="alert alert-danger d-none face" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>

            <h1 class="text-center">Don hang</h1>
            <div class="row">
                <div class="col col-md-12">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>STT</th>
                                <th>Ma Don Hang</th>
                                <th> Ten Khach Hang</th>
                                <th>sdt</th>
                                <th>Dia chi</th>
                                
                                <th>Thoi gian dat</th>
                                <th>thoi gian du kien giao hang</th>
                                <th>tong tien</th>
                                <th>trang thai</th>

                               
                            </tr>
                        </thead>
                        <tbody id="datarow">
                            <?php
                            $id_cus = $_REQUEST['id_cus'];
                            $conn = open_db();
                                $sql = "SELECT qldh.id, hoadon.id_cart, qldh.idHD, hoadon.Time, hoadon.expected_deli, hoadon.sum, qldh.status, customer.name, customer.address, customer.phoneNum FROM qldh, hoadon, customer WHERE qldh.idHD = hoadon.id AND hoadon.id_cus = customer.id AND customer.id =".$id_cus;
                                $result = mysqli_query($conn, $sql);
                                $countDBRows = mysqli_num_rows($result);
                                $i = 1;
                                while($row = mysqli_fetch_assoc($result)){

                            ?>
                            <tr>
                                <td style ="text-align: center;"><?= $i++ ?></td>
                                <input type="hidden" name="idCart" value = <?= $row['id_cart']?>>
                                <td style ="text-align: center;" > <a href="hd_detail.php?idCart=<?=$row['id_cart'] ?>"><?= $row['idHD']?></a></td>
                                </td>
                                <td style ="text-align: center;"><?= $row['name'] ?></td>
                                <td style ="text-align: center;"><?= $row['phoneNum'] ?></td>
                                <td style ="text-align: center;"><?= $row['address'] ?></td>
                                
                                <td style ="text-align: center;"><?= $row['Time'] ?></td>
                                <td style ="text-align: center;"><?= $row['expected_deli'] ?></td>
                                <td style ="text-align: center;"><?= number_format($row['sum'], 0, '', ',') ?></td>
                                <td style ="text-align: center;" > <?php 
                                    if($row['status']==0){
                                        echo "processing";
                                    }else if($row['status']==1){
                                        echo "done";
                                    }else if($row['status']==2){
                                        echo "canceled";
                                    }
                                
                                
                                ?>
                                </td>
                            </tr>
                            <?php 
                                }
                            ?>
                            
                        </tbody>
                    </table>

                    <a href="index.php" class="btn btn-warning btn-md"><i class="fa fa-arrow-left"
                            aria-hidden="true"></i>&nbsp;Quay
                        về trang chủ</a>
                        <button href="" class="btn btn-primary btn-md" >Cap Nhat</button>
                </div>
            </div>
        </div>
        <!-- End block content -->
    </form>
    </main>

    <footer class="footer mt-auto py-3">
        <div class="container">
            <span>Bản quyền © bởi <a href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a> - <script>document.write(new Date().getFullYear());</script>.</span>
            <span class="text-muted">Hành trang tới Tương lai</span>

            <p class="float-right">
                <a href="#">Về đầu trang</a>
            </p>
        </div>
    </footer>
    <!-- end footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/popperjs/popper.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom script - Các file js do mình tự viết -->
    <script src="../assets/js/app.js"></script>

    <script>
        function change_value(){
            if (window.confirm("Ban co muon than toan khong")) {
                window.alert("Thanks for purchasing!")
             window.open("index.php", "Thanks for purchasing!");
            }
    
        }

    </script>

</body>

</html>