<?php 
require_once('connect.php');

$conn = open_db();

$sql = "UPDATE cart 
SET quantity ="

?>