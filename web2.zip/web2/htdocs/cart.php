<!DOCTYPE html>
<html lang="vi" class="h-100">
<?php 
require_once('lib_session.php');
require_once('connect.php');
$conn = open_db();
?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nền tảng - Kiến thức cơ bản về WEB | Bảng tin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Custom css - Các file css do chúng ta tự viết -->
    <link rel="stylesheet" href="../assets/css/app.css" type="text/css">
</head>

<body>
     <!-- header -->
     <style>
    .dropbtn {
    background-color: #4CAF50;
    color: #343a40;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }
  
  .dropdown {
    position: relative;
    display: inline-block;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #343a40;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown:hover .dropbtn {
    background-color: #3e8e41;
  }
</style>
    <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-dark">
        <div class="container">
            <a class="navbar-brand" href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a>
            <div class="navbar-collapse collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Trang chủ <span class="sr-only">(current)</span></a>
                    </li>
                  
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="products.php" class="nav-link">San Pham</a> 
                            <div class="dropdown-content">
                                <a href="dt.php">Dien Thoai</a>
                                <a href="lt.php">LapTop</a>
                                <a href="tb.php">Tablet</a>
                            </div>
                        </div>
                    </li>
                    <?php
							if (isAdminLogged()) {?>
                    
                        <li class="nav-item">
                        <a class="nav-link" href="new_product.php">Thêm Sản phẩm</a> 
                        <?php
                    }?>
						
                    
                    </li>
                    <li class="nav-item">
                    <?php
							if (isAdminLogged()) {?>
                        <a class="nav-link" href="quanlydonhang.php">Quan ly don hang</a> 
                        <?php
                    }?>
                    </li>
                </ul>
                <form class="form-inline mt-2 mt-md-0" method="get" action="search.php">
                    <input class="form-control mr-sm-2" type="text" placeholder="Tìm kiếm" aria-label="Search"
                        name="keyword_tensanpham">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Tìm kiếm</button>
                </form>
            </div>
            <ul class="navbar-nav px-3">
                <li class="nav-item text-nowrap">
                    <a class="nav-link" href="cart.php">Giỏ hàng</a>
                </li>
                <li class="nav-item text-nowrap">
                    <!-- Nếu chưa đăng nhập thì hiển thị nút Đăng nhập -->
                    <?php
						//var_dump(isAdminLogged());
						if(isAdminLogged()) {
							echo ('<span style="color:red">Admin is logging</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
						}else if(isLogged()){
                            $name = $_SESSION['current_username'];
                            $query ="SELECT customer.name, customer.id FROM customer WHERE customer.username = '$name';";
                            $res = mysqli_query($conn, $query);
                            $r = mysqli_fetch_assoc($res);
                            echo('<input name ="idCus" type="hidden" value ="'.$r['id'].'">');
                            echo ('<span style="color:red">'.$r['name'].'</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
                        }
						else {
							echo ('<a class ="nav-link" href="login.php">Đăng nhập</a>');
						}
					?>
                    
                </li>
            </ul>
        </div>
    </nav>
    <!-- end header -->

    <main role="main">
        <!-- Block content - Đục lỗ trên giao diện bố cục chung, đặt tên là `content` -->
        <div class="container mt-4">
            <form name="xulysanpham" action="xuly_thanhtoan.php" method ="get">
            <div id="thongbao" class="alert alert-danger d-none face" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>

            <h1 class="text-center">Giỏ hàng</h1>
            <div class="row">
                <div class="col col-md-12">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>STT</th>
                                <th>Tên sản phẩm</th>
                                <th>Số lượng</th>
                                <th>Đơn giá</th>
                                <th>Thành tiền</th>
                               
                            </tr>
                        </thead>
                        <tbody id="datarow">
                            <?php
                                if(islogged() && !isAdminLogged()){
                                    $id_cus = $r['id'];
                                    $query = "SELECT id FROM cart WHERE id_cus = $id_cus AND STATUS =0";
                                    $check = mysqli_query($conn, $query);
                                    $countDBRows = mysqli_num_rows($check);
                                    if($countDBRows > 0){
                                        $checkid = mysqli_fetch_assoc($check);
                                        $id_cart = $checkid['id'];
                                        $sql = "SELECT * FROM cartitem WHERE idCart = $id_cart";
                                        $result = mysqli_query($conn, $sql);
                                        $countDBRows = mysqli_num_rows($result);
                                    }else{
                                        $sql = "SELECT * FROM cartitem WHERE id = 0";
                                        $result = mysqli_query($conn, $sql);
                                        $countDBRows = mysqli_num_rows($result);
                                    }  
                                    
                                }else{
                                    $sql = "SELECT * FROM cartitem WHERE id = 0";
                                    $result = mysqli_query($conn, $sql);
                                    $countDBRows = mysqli_num_rows($result);
                                }
                               
                                $i = 1;
                                while($row = mysqli_fetch_assoc($result)){
                                    $sql = "SELECT * FROM sanpham 
                                    WHERE id = ".$row['id_product'];
        
                                    $result1 = mysqli_query($conn, $sql);
                                    $row1 = mysqli_fetch_assoc($result1);

                            ?>
                            <tr>
                                <td style ="text-align: center;"><?= $i++ ?></td>
                                
                                <td style ="text-align: center;" ><a href="product-detail.php?idSp=<?=$row['id_product']?>"  style ="color: black;"><?= $row1['TenSP']?></a>
                                </td>
                                <td  style ="text-align: center;"> <input type="number" class="form-control" id="soluong" name="soluong" value ='<?= $row['quantity']?>' onChange = ""></td>
                                <td  style ="text-align: center;"><?= number_format($row1['GiaSP'], 0, '', ',')?></td>
                                <td  style ="text-align: center;"><?= number_format($row1['GiaSP']*$row['quantity'], 0, '', ',')?></td>
                                <td>
                                    <input type="hidden" name ="idCart" value ="<?=$id_cart?>">
                                    <input type="hidden" name ="id" value ="<?=$row['id']?>">

                                    <!-- Nút xóa, bấm vào sẽ xóa thông tin dựa vào khóa chính `sp_ma` -->
                                    <a data-sp-ma="2" class="btn btn-danger btn-delete-sanpham" href="qlsp.php?del1=1&idCart=<?=$id_cart?>&id=<?=$row['id']?>" onclick="return confirm('Are you sure?');">
                                        <i class="fa fa-trash" aria-hidden="true"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                            <?php 
                                }
                            ?>
                            
                        </tbody>
                    </table>

                    <a href="index.php" class="btn btn-warning btn-md"><i class="fa fa-arrow-left"
                            aria-hidden="true"></i>&nbsp;Quay
                        về trang chủ</a>
                        
                        <button href="xuly_thanhtoan.php" class="btn btn-primary btn-md"><i
                            class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;Thanh toán</button>
                </div>
            </div>
                            </form>
        </div>
        <!-- End block content -->
    </main>
    <?php 
    if(islogged()){
        ?>
        <h6 style ="text-align: center;"><a  href="dh.php?id_cus=<?=$r['id'] ?>" >Don hang da dat</a></h6>
        
        <?php
    }
    
    
    ?>

    <footer class="footer mt-auto py-3">
        <div class="container">
            <span>Bản quyền © bởi <a href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a> - <script>document.write(new Date().getFullYear());</script>.</span>
            <span class="text-muted">Hành trang tới Tương lai</span>

            <p class="float-right">
                <a href="#">Về đầu trang</a>
            </p>
        </div>
    </footer>
    <!-- end footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/popperjs/popper.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom script - Các file js do mình tự viết -->
    <script src="../assets/js/app.js"></script>

    <script>
        function change_value(){
            if (window.confirm("Ban co muon than toan khong")) {
                window.alert("Thanks for purchasing!")
             window.open("index.php", "Thanks for purchasing!");
            }
    
        }

    </script>

</body>

</html>