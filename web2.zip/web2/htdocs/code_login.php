<?php
require_once('lib_session.php');

$user = $_REQUEST['username'];
$pass = $_REQUEST['password'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = sprintf("SELECT * FROM account WHERE username='%s'", $user);
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_assoc($result);
	if($user == "admin" && $row['password'] == $pass){
		echo 'Dang nhap thanh cong';
		$_SESSION['current_username'] = $user;
		$_SESSION['isAdmin'] = true;
		header('Location:' . 'products.php');
	}
	else if ($row['password'] == $pass) {
		// dang nhap thanh cong
		echo 'Dang nhap thanh cong';
		$_SESSION['current_username'] = $user;
		$_SESSION['isAdmin'] = false;
		header('Location:' . 'products.php');
	}
	else {
		
		?>
		<script>
			window.alert("sai password")
			<?php
				header('Location:' . 'login.php');
			?>
		</script>
		<?php 
	}
}
else {
	header('Location:' . 'login.php')
	?>
		<script>
			alert("khong ton tai username")
		</script>
		<?php 
		header('Location:' . 'products.php');
}

mysqli_close($conn);
?>