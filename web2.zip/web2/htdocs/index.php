<!DOCTYPE html>
<html lang="vi" class="h-100">
<?php
require_once('lib_session.php');
require_once('connect.php');
require_once ('pagination.php');

$sql = "SELECT * FROM sanpham";
$result = mysqli_query(open_db(), $sql);
$countDBRows = mysqli_num_rows($result);


$conn = open_db();

$mysql_query = mysqli_query($conn, "SELECT * FROM sanpham");
$total_rows = mysqli_num_rows($mysql_query);
$limit = 9;
$total_page = ceil($total_rows/$limit);
$current_page=0;
$offset=0;

if( isset($_GET{'page'} ) ) {
	$current_page = $_GET['page'];
	if($current_page <=0)
		$current_page = 1;
	else if($current_page > $total_page)
		$current_page = $total_page;
	$offset = $limit * ($current_page-1);
}
else{
	$current_page = 1;
	$offset = 0;
}
$request_url = basename($_SERVER['REQUEST_URI']);
$pagination = create_pagination($request_url, $limit, $total_page, $current_page);

$sql = "SELECT * FROM sanpham Limit $offset, $limit;";
$result = mysqli_query($conn, $sql);
$countDBRows = mysqli_num_rows($result);
?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nền tảng - Kiến thức cơ bản về WEB | Bảng tin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css" type="text/css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Custom css - Các file css do chúng ta tự viết -->
    <link rel="stylesheet" href="assets/css/app.css" type="text/css">
</head>

<body>
    
    <!-- header -->
    <style>
    .dropbtn {
    background-color: #4CAF50;
    color: #343a40;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }
  
  .dropdown {
    position: relative;
    display: inline-block;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #343a40;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown:hover .dropbtn {
    background-color: #3e8e41;
  }
</style>
    <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-dark">
        <div class="container">
            <a class="navbar-brand" href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a>
            <div class="navbar-collapse collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Trang chủ <span class="sr-only">(current)</span></a>
                    </li>
                  
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="products.php" class="nav-link">San Pham</a> 
                            <div class="dropdown-content">
                                <a href="dt.php">Dien Thoai</a>
                                <a href="lt.php">LapTop</a>
                                <a href="tb.php">Tablet</a>
                            </div>
                        </div>
                    </li>
                    <?php
							if (isAdminLogged()) {?>
                    
                        <li class="nav-item">
                        <a class="nav-link" href="new_product.php">Thêm Sản phẩm</a> 
                        <?php
                    }?>
						
                    
                    </li>
                    <li class="nav-item">
                    <?php
							if (isAdminLogged()) {?>
                        <a class="nav-link" href="quanlydonhang.php">Quan ly don hang</a> 
                        <?php
                    }?>
                    </li>
                </ul>
                <form class="form-inline mt-2 mt-md-0" method="get" action="search.php">
                    <input class="form-control mr-sm-2" type="text" placeholder="Tìm kiếm" aria-label="Search"
                        name="keyword_tensanpham">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Tìm kiếm</button>
                </form>
            </div>
            <ul class="navbar-nav px-3">
                <li class="nav-item text-nowrap">
                    <a class="nav-link" href="cart.php">Giỏ hàng</a>
                </li>
                <li class="nav-item text-nowrap">
                    <!-- Nếu chưa đăng nhập thì hiển thị nút Đăng nhập -->
                    <?php
						//var_dump(isAdminLogged());
						if(isAdminLogged()) {
							echo ('<span style="color:red">Admin is logging</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
						}else if(isLogged()){
                            $name = $_SESSION['current_username'];
                            $query ="SELECT customer.name, customer.id FROM customer WHERE customer.username = '$name';";
                            $res = mysqli_query($conn, $query);
                            $r = mysqli_fetch_assoc($res);
                            echo('<input name ="idCus" type="hidden" value ="'.$r['id'].'">');
                            echo ('<span style="color:red">'.$r['name'].'</span> <br/>');
							echo ('<a class="nav-link" href="logout.php?isAdmin=1">Đăng xuat</a>');
                        }
						else {
							echo ('<a class ="nav-link" href="login.php">Đăng nhập</a>');
						}
					?>
                    
                </li>
            </ul>
        </div>
    </nav>
    <!-- end header -->
    <main role="main">
        <!-- Block content - Đục lỗ trên giao diện bố cục chung, đặt tên là `content` -->
        <!-- Carousel - Slider -->
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1" class=""></li>
                <li data-target="#myCarousel" data-slide-to="2" class=""></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/slider/slider-1.jpg">
                    <div class="container">
                        <div class="carousel-caption text-left">
                            <h1>Nền Tảng - Nơi mua sắm tuyệt vời</h1>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slider/slider-2.jpg">
                    <div class="container">
                        <div class="carousel-caption">
                            <h1>Hàng triệu sản phẩm - Lựa chọn mỏi tay</h1>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slider/slider-3.jpg">
                    <div class="container">
                        <div class="carousel-caption text-right">
                            <h1>Chất lượng là Hàng đầu.</h1>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <!-- Tính năng Marketing -->
        <div class="container marketing">
            <!-- Three columns of text below the carousel -->
            <div class="row">
                <div class="col-lg-4">
                    <img class="bd-placeholder-img rounded-circle" width="140" height="140"
                        src="assets/img/icon/icon-1.png">
                    <h2>Đặt hàng</h2>
                    <p>Chọn sản phẩm bạn yêu thích, và Đặt hàng.</p>
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <img class="bd-placeholder-img rounded-circle" width="140" height="140"
                        src="assets/img/icon/icon-2.png">
                    <h2>Tạo đơn hàng</h2>
                    <p>Theo dõi đơn hàng của bạn.</p>
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <img class="bd-placeholder-img rounded-circle" width="140" height="140"
                        src="assets/img/icon/icon-3.png">
                    <h2>Giao hàng</h2>
                    <p>Giao hàng tận nơi.</p>
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->


            <!-- START THE FEATURETTES -->
            <hr class="featurette-divider">
            <div class="row featurette">
                <div class="col-md-7">
                    <h2 class="featurette-heading">Đặt hàng, Tạo đơn hàng, Giao hàng <span class="text-muted">Nhanh
                            chóng</span>
                    </h2>
                    <p class="lead">Nơi mua sắm tuyệt vời cho mọi lứa tuổi.</p>
                </div>
                <div class="col-md-5">
                    <img src="assets/img/marketing/marketing-1.png">
                </div>
            </div>

            <hr class="featurette-divider">
            <div class="row featurette">
                <div class="col-md-7 order-md-2">
                    <h2 class="featurette-heading">Báo cáo Doanh thu tuyệt vời <span class="text-muted">Theo dõi đơn
                            hàng của
                            bạn.</span></h2>
                    <p class="lead">Hệ thống theo dõi đơn hàng chi tiết, thông tin mọi lúc mọi nơi.</p>
                </div>
                <div class="col-md-5 order-md-1">
                    <img src="assets/img/marketing/marketing-2.png">
                </div>
            </div>

            <hr class="featurette-divider">
            <!-- /END THE FEATURETTES -->
        </div>

        <!-- Danh sách sản phẩm -->
        <section class="jumbotron text-center">
            <div class="container">
                <h1 class="jumbotron-heading">Danh sách Sản phẩm</h1>
                <p class="lead text-muted">Các sản phẩm với chất lượng, uy tín, cam kết từ nhà Sản xuất, phân phối và
                    bảo hành
                    chính hãng.</p>
            </div>
        </section>

        <!-- Giải thuật duyệt và render Danh sách sản phẩm theo dòng, cột của Bootstrap -->
        <div class="danhsachsanpham py-5 bg-light">
            <div class="container">
			<?php
				//var_dump($countDBRows);
				$countUIRow = 0;
				$s = '';
				while($row = mysqli_fetch_assoc($result)) {
					if($countUIRow == 0) {
						echo '<div class="row">';
					}
					// add col
					echo '<div class="col-md-4">';
					
					// content of col here ?>
					<div class="card mb-4 shadow-sm">
						<a href="product-detail.php?idSp=<?=$row['id']?>">
							<img class="bd-placeholder-img card-img-top" width="100%" height="350"
								src="<?=$row['HinhSP']?>">
						</a>
						<div class="card-body">
							<a href="product-detail.html">
								<h5><?=$row['TenSP']?></h5>
							</a>
							<h6>Điện thoại</h6>                         
							<div class="d-flex justify-content-between align-items-center">
								<div class="btn-group">
								</div>
								<small class="text-muted text-right">
									<b><?=number_format($row['GiaSP'], 0, '', ',')?> vnđ</b>
								</small>
							</div>
							<?php
							if (isAdminLogged()) { ?>
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="edit_product.php?id=<?=$row['id']?>">Edit</a>
                                    <a href="qlsp.php?del=1&id=<?=$row['id']?>" onclick="return confirm('Are you sure?');">Del</a>
                                </div>
							<?php
							}
							?>
						</div>
					</div>
					<?php
					echo '</div>'; // end of col
					$countUIRow++;
					if($countUIRow == 3) {
						echo '</div>'; // end of row
						$countUIRow = 0;
					}
				};
				if($countUIRow > 0) {
					echo '</div>';
				}
				//echo $s;
			?>
            </div>
        </div>

        <!-- End block content -->
    </main>
    <div class="navigation" style=" text-align: center;"><a href="products.php">view more</a></div>
    <?php close_db();?>

    <!-- footer -->
    <footer class="footer mt-auto py-3">
        <div class="container">
            <span>Bản quyền © bởi <a href="https://www.facebook.com/mainguyentrungkienn2509/">Kien's Store</a> - <script>document.write(new Date().getFullYear());</script>.</span>
            <span class="text-muted">Hành trang tới Tương lai</span>

            <p class="float-right">
                <a href="#">Về đầu trang</a>
            </p>
        </div>
    </footer>
    <!-- end footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popperjs/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom script - Các file js do mình tự viết -->
    <script src="assets/js/app.js"></script>

</body>


</html>